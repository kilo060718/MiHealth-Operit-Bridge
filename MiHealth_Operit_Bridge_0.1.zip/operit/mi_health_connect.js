/*
METADATA
{
  "name": "mi_health_connect",
  "display_name": {
    "zh": "小米健康数据",
    "en": "Mi Health Connect"
  },
  "description": {
    "zh": "通过本机 Health Connect 桥接程序读取小米运动健康的今日运动数据。",
    "en": "Read today's Mi Fitness data through a local Health Connect bridge."
  },
  "category": "HEALTH",
  "tools": [
    {
      "name": "get_today",
      "description": {
        "zh": "读取今天的步数、距离、主动消耗和总消耗。只读，不修改健康数据。",
        "en": "Read today's steps, distance, active calories and total calories. Read-only."
      },
      "parameters": []
    },
    {
      "name": "get_raw",
      "description": {
        "zh": "读取桥接程序返回的原始 JSON，用于排查数据源问题。",
        "en": "Read the raw JSON from the local bridge for troubleshooting."
      },
      "parameters": []
    }
  ]
}
*/

async function get_raw(params) {
    try {
        const raw = await Tools.Net.httpGet("http://127.0.0.1:8765/today");
        complete(String(raw));
    } catch (e) {
        complete(JSON.stringify({
            ok: false,
            error: "无法连接 Health Connect 桥接程序。请先打开 Mi Health → Operit，并确认它正在运行。",
            detail: String(e)
        }));
    }
}

async function get_today(params) {
    try {
        const raw = await Tools.Net.httpGet("http://127.0.0.1:8765/today");
        let data;
        try {
            data = typeof raw === "string" ? JSON.parse(raw) : raw;
        } catch (_) {
            data = { raw: String(raw) };
        }
        complete(JSON.stringify(data));
    } catch (e) {
        complete(JSON.stringify({
            ok: false,
            error: "无法连接 Health Connect 桥接程序。请先打开 Mi Health → Operit。",
            detail: String(e)
        }));
    }
}

exports.get_today = get_today;
exports.get_raw = get_raw;
