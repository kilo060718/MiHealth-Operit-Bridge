
# Mi Health → Operit Bridge 0.1

这版已经补上了 **127.0.0.1:8765 本机 HTTP 桥接层**。

数据链路：

小米运动健康 → Health Connect → Mi Health → Operit

## Android App

App 使用 Health Connect 1.1.0 stable。

启动 App 后：

1. 点击“授权 Health Connect”
2. 在 Health Connect 中允许本 App 读取：
   - Steps
   - Distance
   - Active calories
   - Total calories
   - Exercise
3. 回到 App，点击“测试今日数据”
4. 保持这个 App 的进程存活，然后打开 Operit

HTTP endpoints：

- `GET http://127.0.0.1:8765/health`
- `GET http://127.0.0.1:8765/today`

目前 `/today` 返回：

```json
{
  "ok": true,
  "date": "2026-09-14",
  "timezone": "Europe/London",
  "steps": 12345,
  "distance_km": 8.123,
  "active_kcal": 321.0,
  "total_kcal": 1842.0
}
```

## Operit

把 `operit/mi_health_connect.js` 导入 Operit 的 Sandbox Package。

它提供：

- `mi_health_connect:get_today`
- `mi_health_connect:get_raw`

### 注意

这是第一版原型。桥接 App 是普通 Android App，因此如果 Android 系统把它的进程杀掉，Operit 会暂时无法访问 `127.0.0.1:8765`。测试阶段保持桥接 App 最近使用即可。

下一版可以改成前台服务，让桥接常驻，并加入：
- 睡眠
- 心率
- 血氧
- 最近运动记录
- 按日期查询
- 指定数据来源
