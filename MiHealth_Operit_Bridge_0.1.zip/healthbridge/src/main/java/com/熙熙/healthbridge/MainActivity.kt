
package com.xixi.healthbridge

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContract
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import java.util.concurrent.Executors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    private lateinit var client: HealthConnectClient
    private lateinit var status: TextView

    private val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    )

    private val permissionLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
            status.text = "Health Connect 权限已返回。现在可以让 Operit 读取。"
        }

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        client = HealthConnectClient.getOrCreate(this)

        status = TextView(this).apply {
            textSize = 16f
            text = "本机桥接地址：127.0.0.1:8765"
            setPadding(32, 48, 32, 32)
        }

        val grant = Button(this).apply {
            text = "授权 Health Connect"
            setOnClickListener { permissionLauncher.launch(permissions) }
        }

        val test = Button(this).apply {
            text = "测试今日数据"
            setOnClickListener {
                pool.execute {
                    val result = runCatching { readTodayJson() }
                    runOnUiThread {
                        status.text = result.fold(
                            onSuccess = { "桥接正常：$it" },
                            onFailure = { "读取失败：${it.javaClass.simpleName}: ${it.message}" }
                        )
                    }
                }
            }
        }

        val info = TextView(this).apply {
            text = """
数据链路：
小米运动健康 → Health Connect → 本程序 → Operit

Operit 插件：
mi_health_connect:get_today

HTTP：
GET http://127.0.0.1:8765/health
GET http://127.0.0.1:8765/today

只读，不修改健康数据。
            """.trimIndent()
            setPadding(32, 24, 32, 32)
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(grant)
            addView(test)
            addView(info)
        })

        startLocalServer()
    }

    private fun startLocalServer() {
        pool.execute {
            try {
                server = ServerSocket(8765, 20, java.net.InetAddress.getByName("127.0.0.1"))
                while (!server!!.isClosed) {
                    val socket = server!!.accept()
                    pool.execute { handle(socket) }
                }
            } catch (_: Exception) {
                // Server closed or process is stopping.
            }
        }
    }

    private fun handle(socket: Socket) {
        socket.use {
            try {
                val reader = BufferedReader(InputStreamReader(it.getInputStream(), Charsets.UTF_8))
                val first = reader.readLine() ?: return
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                }

                val path = first.split(" ").getOrNull(1)?.substringBefore("?") ?: "/"
                val body = when (path) {
                    "/health" -> JSONObject()
                        .put("ok", true)
                        .put("service", "mi_health_connect_bridge")
                        .put("version", "0.1.0")
                        .toString()
                    "/today" -> runCatching { readTodayJson() }
                        .getOrElse {
                            JSONObject()
                                .put("ok", false)
                                .put("error", it.message ?: it.javaClass.simpleName)
                                .toString()
                        }
                    else -> JSONObject()
                        .put("ok", false)
                        .put("error", "Not found")
                        .toString()
                }

                val statusCode = if (path == "/health" || path == "/today") "200 OK" else "404 Not Found"
                val out = PrintWriter(it.getOutputStream(), false)
                out.print(
                    "HTTP/1.1 $statusCode\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Cache-Control: no-store\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: ${body.toByteArray(Charsets.UTF_8).size}\r\n" +
                    "Connection: close\r\n\r\n" +
                    body
                )
                out.flush()
            } catch (_: Exception) {
                // Ignore broken local client connections.
            }
        }
    }

    private fun readTodayJson(): String = runBlocking(Dispatchers.IO) {
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.containsAll(permissions)) {
            return@runBlocking JSONObject()
                .put("ok", false)
                .put("error", "Health Connect permissions are incomplete")
                .put("granted", granted.toList())
                .toString()
        }

        val zone = ZoneId.systemDefault()
        val start = ZonedDateTime.now(zone).toLocalDate().atStartOfDay(zone).toInstant()
        val end = Instant.now()

        val result = client.aggregate(
            AggregateRequest(
                metrics = setOf(
                    StepsRecord.COUNT_TOTAL,
                    DistanceRecord.DISTANCE_TOTAL,
                    ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                    TotalCaloriesBurnedRecord.ENERGY_TOTAL
                ),
                timeRangeFilter = TimeRangeFilter.between(start, end)
            )
        )

        val steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
        val distance = result[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0
        val activeKcal = result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
        val totalKcal = result[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0

        JSONObject()
            .put("ok", true)
            .put("date", ZonedDateTime.now(zone).toLocalDate().toString())
            .put("timezone", zone.id)
            .put("steps", steps)
            .put("distance_km", String.format(Locale.US, "%.3f", distance).toDouble())
            .put("active_kcal", String.format(Locale.US, "%.1f", activeKcal).toDouble())
            .put("total_kcal", String.format(Locale.US, "%.1f", totalKcal).toDouble())
            .toString()
    }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
        super.onDestroy()
    }
}
